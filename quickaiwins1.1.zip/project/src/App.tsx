import React from 'react';
import Logo from './components/Logo';
import Divider from './components/Divider';
import HeroSection from './components/sections/HeroSection';
import PainPointsSection from './components/sections/PainPointsSection';
import ProcessSection from './components/sections/ProcessSection';
import TransformationSection from './components/sections/TransformationSection';
import SuccessStoriesSection from './components/sections/SuccessStoriesSection';
import ValuePropsSection from './components/sections/ValuePropsSection';
import PricingSection from './components/sections/PricingSection';
import PreFooterSection from './components/sections/PreFooterSection';
import CTASection from './components/sections/CTASection';

export default function App() {
  return (
    <div className="min-h-screen bg-paper-light">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-paper-light/80 backdrop-blur-sm z-50 border-b border-line">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <a href="#" className="transform hover:scale-105 transition-transform">
              <Logo />
            </a>
            <a 
              href="#start" 
              className="bg-accent text-white px-4 sm:px-6 h-10 rounded-md hover:bg-accent-dark transition-colors font-handwritten text-base sm:text-lg inline-flex items-center"
            >
              Get Started
            </a>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative pt-16">
        {/* Blue margin line - hidden on mobile */}
        <div className="hidden md:block fixed top-0 left-[1.25in] bottom-0 w-[1px] bg-accent z-10" />

        {/* Content with dot grid */}
        <div className="min-h-screen relative bg-[radial-gradient(circle,_#B9D2DC_1px,_transparent_1px)_0_0] bg-[size:2.175rem_2.175rem]">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <HeroSection />
            <Divider />
            <PainPointsSection />
            <Divider />
            <ProcessSection />
            <Divider />
            <TransformationSection />
            <Divider />
            <SuccessStoriesSection />
            <Divider />
            <ValuePropsSection />
            <Divider />
            <PricingSection />
            <Divider />
            <PreFooterSection />
            <Divider />
            <CTASection />
          </div>
        </div>
      </main>
    </div>
  );
}