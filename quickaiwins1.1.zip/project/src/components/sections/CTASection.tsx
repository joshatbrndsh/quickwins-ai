import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

export default function CTASection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section ref={ref} id="start" className="pl-4 md:pl-20 leading-line pb-8 sm:pb-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6 }}
        className="flex flex-col items-center text-center"
      >
        <h2 className="text-3xl sm:text-4xl font-handwritten font-bold text-ink [line-height:1.2] sm:[line-height:4.35rem]">
          Ready to Transform Your First Process? (It's On Us)
        </h2>
        <p className="text-lg sm:text-xl font-handwritten text-ink-light mt-4 sm:mt-line mb-6 sm:mb-[4.35rem]">
          Start with one process. Get a free enhancement guide.<br className="hidden sm:block" />
          We'll show you exactly how to capture and transform your workflow.
        </p>
        <form className="w-full max-w-lg mt-4 sm:mt-line bg-white/50 p-4 sm:p-8 rounded-lg">
          <div className="mb-4 sm:mb-line">
            <label htmlFor="email" className="block font-handwritten text-ink mb-2">Work Email</label>
            <input
              type="email"
              id="email"
              className="w-full h-10 sm:h-line px-4 border-2 border-line focus:border-accent rounded-md outline-none bg-white/80 font-handwritten text-sm sm:text-base"
              placeholder="you@company.com"
            />
          </div>
          <div className="mb-4 sm:mb-line">
            <label htmlFor="process" className="block font-handwritten text-ink mb-2">What Process Takes Too Long?</label>
            <textarea
              id="process"
              rows={4}
              className="w-full px-4 py-2 border-2 border-line focus:border-accent rounded-md outline-none bg-white/80 leading-relaxed sm:leading-line font-handwritten text-sm sm:text-base"
              placeholder="Tell us about a process you'd like to transform (e.g., monthly reporting, client proposals)"
              style={{ height: 'calc(2.175rem * 4 + 1px)' }}
            />
          </div>
          <button 
            type="submit" 
            className="w-full bg-accent text-white h-10 sm:h-line rounded-md hover:bg-accent-dark transition-colors font-handwritten text-base sm:text-lg flex items-center justify-center gap-2"
          >
            Get Your Free Process Recording Guide →
          </button>
          <p className="mt-4 text-xs sm:text-sm font-handwritten text-ink-light text-center">
            We'll send you step-by-step instructions to record your process<br className="hidden sm:block" />
            and get started with Quick AI Wins.
          </p>
        </form>
      </motion.div>
    </section>
  );
}